#!/bin/bash
java -jar run.jar musicnostalgie